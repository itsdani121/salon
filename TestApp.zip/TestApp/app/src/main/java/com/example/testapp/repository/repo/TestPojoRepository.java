package com.example.testapp.repository.repo;

public class TestPojoRepository {

}
